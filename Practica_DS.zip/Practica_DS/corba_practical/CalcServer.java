import WssCalculator.*;
import org.omg.CORBA.*;
import org.omg.CosNaming.*;
import org.omg.CosNaming.NamingContextExt;
import org.omg.PortableServer.*;

class CalcImpl extends CalcPOA {

    private ORB orb;

    public void setORB(ORB orb_val) {
        orb = orb_val;
    }

    public int calculate(int operator, int num1, int num2) {

        if (operator == 43) return num1 + num2;
        else if (operator == 45) return num1 - num2;
        else if (operator == 42) return num1 * num2;
        else if (operator == 47) return (num2 == 0) ? 0 : num1 / num2;
        else return 0;
    }

    public void shutdown() {
        orb.shutdown(false);
    }
}

public class CalcServer {

    public static void main(String args[]) {

        try {

            ORB orb = ORB.init(args, null);

            POA rootpoa = POAHelper.narrow(
                    orb.resolve_initial_references("RootPOA"));

            rootpoa.the_POAManager().activate();

            CalcImpl impl = new CalcImpl();
            impl.setORB(orb);

            org.omg.CORBA.Object ref =
                    rootpoa.servant_to_reference(impl);

            Calc href = CalcHelper.narrow(ref);

            org.omg.CORBA.Object objRef =
                    orb.resolve_initial_references("NameService");

            NamingContextExt ncRef =
                    NamingContextExtHelper.narrow(objRef);

            String name = "Calc";

            NameComponent path[] = ncRef.to_name(name);

            ncRef.rebind(path, href);

            System.out.println("Calc Server Ready...");

            orb.run();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
