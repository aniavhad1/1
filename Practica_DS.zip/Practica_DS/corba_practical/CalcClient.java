import WssCalculator.*;
import org.omg.CORBA.*;
import org.omg.CosNaming.*;
import org.omg.CosNaming.NamingContextExt;

import java.io.*;

public class CalcClient {

    static Calc cimpl;

    public static void main(String args[]) {

        try {

            ORB orb = ORB.init(args, null);

            org.omg.CORBA.Object objRef =
                    orb.resolve_initial_references("NameService");

            NamingContextExt ncRef =
                    NamingContextExtHelper.narrow(objRef);

            String name = "Calc";

            cimpl = CalcHelper.narrow(ncRef.resolve_str(name));

            System.out.println("Connected to server");

            BufferedReader br =
                    new BufferedReader(new InputStreamReader(System.in));

            while (true) {

                System.out.println("Enter expression (e.g. 12 + 34):");
                String input = br.readLine().replaceAll("\\s+", "");

                // find operator dynamically
                int pos = -1;
                char op = ' ';

                for (int i = 0; i < input.length(); i++) {
                    char ch = input.charAt(i);
                    if (ch == '+' || ch == '-' || ch == '*' || ch == '/') {
                        op = ch;
                        pos = i;
                        break;
                    }
                }

                int num1 = Integer.parseInt(input.substring(0, pos));
                int num2 = Integer.parseInt(input.substring(pos + 1));

                int operator = (int) op;

                int result = cimpl.calculate(operator, num1, num2);

                System.out.println("Result = " + result);

                System.out.println("Continue? (1/0)");
                if (Integer.parseInt(br.readLine()) == 0) break;
            }

            cimpl.shutdown();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
