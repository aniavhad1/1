import java.rmi.*;

public class Client{
	public static void main (String[] args){
		try{
			Adder stub = (Adder) Naming.lookup("rmi://localhost/Server");

			System.out.println(stub.add(5,5));
		}catch (Exception e){
			System.out.println("Exception occured at client" + e);
		}
	}
}
