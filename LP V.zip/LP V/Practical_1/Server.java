import java.rmi.*;

public class Server{
	public static void main (String[] args){
		try{
			Adder stub = new AdderRemote();
			Naming.rebind("Server", stub);
		}catch (Exception e){
			System.out.println("Exceptionn occured at service" + e);		
		}



}
}
