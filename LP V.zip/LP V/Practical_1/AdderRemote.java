import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;

public class AdderRemote extends UnicastRemoteObject implements Adder{
	public AdderRemote() throws RemoteException{}

	public int add(int var1, int var2) throws RemoteException{
		return var1 + var2;
	}
}
