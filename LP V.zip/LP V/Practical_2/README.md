## Compile IDL
idlj -fall Calc.idl

## Compilation Commands
javac *.java WssCalculator/*.java

## Start Naming Service
orbd -ORBInitialPort 1050 -ORBInitialHost localhost

## Run Server
java CalcServer -ORBInitialPort 1050 -ORBInitialHost localhost

## Run Client
java CalcClient -ORBInitialPort 1050 -ORBInitialHost localhost
