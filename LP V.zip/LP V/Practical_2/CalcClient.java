import WssCalculator.*;
import org.omg.CosNaming.*;
import org.omg.CORBA.*;
import java.io.*;

public class CalcClient {
    public static void main(String args[]) {
        try {
            ORB orb = ORB.init(args, null);

            org.omg.CORBA.Object objRef =
                orb.resolve_initial_references("NameService");

            NamingContextExt ncRef =
                NamingContextExtHelper.narrow(objRef);

            Calc calc = CalcHelper.narrow(ncRef.resolve_str("Calc"));

            BufferedReader br = new BufferedReader(
                new InputStreamReader(System.in));

            while (true) {
                System.out.println("Enter expression (e.g. 2+3): ");
                String input = br.readLine();

                if (input.equals("exit")) break;

                char op = input.charAt(1);
                int a = Character.getNumericValue(input.charAt(0));
                int b = Character.getNumericValue(input.charAt(2));

                int result = calc.calculate((int)op, a, b);

                System.out.println("Result: " + result);
            }

            calc.shutdown();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
