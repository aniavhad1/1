import WssCalculator.*;
import org.omg.CosNaming.*;
import org.omg.CORBA.*;
import org.omg.PortableServer.*;

class Calcserverimpl extends CalcPOA {
    private ORB orb;

    public void setORB(ORB orb_val) {
        orb = orb_val;
    }

    public int calculate(int op, int a, int b) {
        switch(op) {
            case 43: return a + b; // +
            case 45: return a - b; // -
            case 42: return a * b; // *
            case 47: return a / b; // /
            default: return 0;
        }
    }

    public void shutdown() {
        orb.shutdown(false);
    }
}

public class CalcServer {
    public static void main(String args[]) {
        try {
            ORB orb = ORB.init(args, null);

            POA rootpoa = POAHelper.narrow(
                orb.resolve_initial_references("RootPOA"));
            rootpoa.the_POAManager().activate();

            Calcserverimpl impl = new Calcserverimpl();
            impl.setORB(orb);

            org.omg.CORBA.Object ref = rootpoa.servant_to_reference(impl);
            Calc href = CalcHelper.narrow(ref);

            org.omg.CORBA.Object objRef =
                orb.resolve_initial_references("NameService");

            NamingContextExt ncRef =
                NamingContextExtHelper.narrow(objRef);

            String name = "Calc";
            NameComponent path[] = ncRef.to_name(name);
            ncRef.rebind(path, href);

            System.out.println("Server READY...");

            orb.run();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
