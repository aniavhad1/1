## Compilation

javac MutualServer.java
javac ClientOne.java
javac ClientTwo.java

## Execution Steps (VERY IMPORTANT)

Step 1: Start Server
java MutualServer

Step 2: Run ClientOne
java ClientOne

Step 3: Run ClientTwo (in new terminal)
java ClientTwo
