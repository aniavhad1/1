import java.io.*;
import java.net.*;

public class ClientOne {
    public static void main(String args[]) throws IOException {

        Socket s = new Socket("localhost", 7000);
        PrintStream out = new PrintStream(s.getOutputStream());

        ServerSocket ss = new ServerSocket(7001);
        Socket s1 = ss.accept();

        BufferedReader in1 = new BufferedReader(
                new InputStreamReader(s1.getInputStream()));
        PrintStream out1 = new PrintStream(s1.getOutputStream());

        BufferedReader br = new BufferedReader(
                new InputStreamReader(System.in));

        String token = "Token";

        while (true) {

            if (token.equalsIgnoreCase("Token")) {
                System.out.println("Do you want to send data? (Yes/No)");
                String choice = br.readLine();

                if (choice.equalsIgnoreCase("Yes")) {
                    System.out.println("Enter data:");
                    String data = br.readLine();
                    out.println(data);
                }

                // Pass token to next client
                out1.println("Token");
            }

            System.out.println("Waiting for Token...");
            token = in1.readLine();
        }
    }
}
