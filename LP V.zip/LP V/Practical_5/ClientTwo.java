import java.io.*;
import java.net.*;

public class ClientTwo {
    public static void main(String args[]) throws IOException {

        Socket s = new Socket("localhost", 7000);
        PrintStream out = new PrintStream(s.getOutputStream());

        Socket s2 = new Socket("localhost", 7001);

        BufferedReader in2 = new BufferedReader(
                new InputStreamReader(s2.getInputStream()));
        PrintStream out2 = new PrintStream(s2.getOutputStream());

        BufferedReader br = new BufferedReader(
                new InputStreamReader(System.in));

        String token;

        while (true) {
            System.out.println("Waiting for Token...");
            token = in2.readLine();

            if (token.equalsIgnoreCase("Token")) {
                System.out.println("Do you want to send data? (Yes/No)");
                String choice = br.readLine();

                if (choice.equalsIgnoreCase("Yes")) {
                    System.out.println("Enter data:");
                    String data = br.readLine();
                    out.println(data);
                }

                // Pass token back
                out2.println("Token");
            }
        }
    }
}
