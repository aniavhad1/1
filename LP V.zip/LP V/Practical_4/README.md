## Compilation
g++ server.cpp -o server
g++ client.cpp -o client

## Execution Steps
1. Run server
./server

2. Run multiple clients (in different terminals)
./client
