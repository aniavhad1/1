#include <iostream>
#include <vector>
#include <string>
#include <cstring>
#include <cstdlib>
#include <ctime>
#include <unistd.h>
#include <arpa/inet.h>
#include <sys/socket.h>

#define PORT 8080
using namespace std;

// Split function
vector<string> split(string s, string delimiter) {
    size_t pos_start = 0, pos_end;
    size_t delim_len = delimiter.length();
    string token;
    vector<string> res;

    while ((pos_end = s.find(delimiter, pos_start)) != string::npos) {
        token = s.substr(pos_start, pos_end - pos_start);
        pos_start = pos_end + delim_len;
        res.push_back(token);
    }

    res.push_back(s.substr(pos_start));
    return res;
}

int main() {
    srand(time(0));
    float server_clock = rand() % 10;

    cout << "Server started\n";
    cout << "Server clock: " << server_clock << endl;

    int server_fd, new_socket;
    struct sockaddr_in address;
    int opt = 1;
    int addrlen = sizeof(address);

    vector<int> client_sockets;
    vector<float> client_clocks;

    // Create socket
    server_fd = socket(AF_INET, SOCK_STREAM, 0);

    setsockopt(server_fd, SOL_SOCKET, SO_REUSEADDR | SO_REUSEPORT, &opt, sizeof(opt));

    address.sin_family = AF_INET;
    address.sin_addr.s_addr = INADDR_ANY;
    address.sin_port = htons(PORT);

    bind(server_fd, (struct sockaddr *)&address, sizeof(address));
    listen(server_fd, 5);

    cout << "Waiting for clients...\n";

    int n;
    cout << "Enter number of clients: ";
    cin >> n;

    // Accept clients
    for(int i = 0; i < n; i++) {
        new_socket = accept(server_fd, (struct sockaddr *)&address, (socklen_t*)&addrlen);
        client_sockets.push_back(new_socket);
        cout << "Client " << i+1 << " connected\n";
    }

    char buffer[1024] = {0};

    // Ask clients for clock
    for(int i = 0; i < n; i++) {
        string msg = "SEND_TIME";
        send(client_sockets[i], msg.c_str(), msg.length(), 0);

        memset(buffer, 0, sizeof(buffer));
        read(client_sockets[i], buffer, 1024);

        float time = stof(string(buffer));
        client_clocks.push_back(time);

        cout << "Received from client " << i+1 << ": " << time << endl;
    }

    // Calculate average
    float sum = server_clock;
    for(float t : client_clocks)
        sum += t;

    float avg = sum / (n + 1);

    cout << "Average time: " << avg << endl;

    // Send adjustments
    for(int i = 0; i < n; i++) {
        float diff = avg - client_clocks[i];
        string msg = to_string(diff);
        send(client_sockets[i], msg.c_str(), msg.length(), 0);
    }

    // Adjust server clock
    server_clock = avg;

    cout << "Updated server clock: " << server_clock << endl;

    close(server_fd);
    return 0;
}
