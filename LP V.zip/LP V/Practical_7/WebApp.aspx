<%@ Page Language="C#" %>

<script runat="server">
void runService_Click(Object sender, EventArgs e)
{
    FirstService mySvc = new FirstService();

    Label1.Text = mySvc.SayHello();

    Label2.Text = mySvc.Add(
        Int32.Parse(txtNum1.Text),
        Int32.Parse(txtNum2.Text)
    ).ToString();
}
</script>

<html>
<body>
<form runat="server">

First Number:
<asp:TextBox id="txtNum1" runat="server">4</asp:TextBox><br/>

Second Number:
<asp:TextBox id="txtNum2" runat="server">5</asp:TextBox><br/><br/>

Result Hello:
<asp:Label id="Label1" runat="server"></asp:Label><br/>

Result Add:
<asp:Label id="Label2" runat="server"></asp:Label><br/><br/>

<asp:Button id="runService"
runat="server"
Text="Execute"
OnClick="runService_Click"/>
</form>
</body>
</html>
