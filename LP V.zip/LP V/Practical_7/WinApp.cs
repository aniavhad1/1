using System;

namespace SvcConsumer
{
    class Program
    {
        static void Main()
        {
            FirstService mySvc = new FirstService();

            Console.WriteLine("Hello Service: " + mySvc.SayHello());
            Console.WriteLine("Add Result: " + mySvc.Add(2, 3));
        }
    }
}
