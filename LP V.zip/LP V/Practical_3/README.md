## C Compiler (GCC)

MPI programs in C need a compiler.
Install:

sudo apt update
sudo apt install gcc

## OpenMPI (Most Important)
This provides:

mpicc → MPI compiler
mpirun → Run parallel programs
mpi.h → Required header file

Install:
sudo apt install openmpi-bin libopenmpi-dev


## Verify Installation
Check compiler:
mpicc --version

Check MPI runtime:
mpirun --version

## Compile:
mpicc sum.c

## Run (4 processes)
mpirun -np 4 ./a.out
