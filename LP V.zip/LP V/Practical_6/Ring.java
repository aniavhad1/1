import java.util.Scanner;

class Process {
    int id;
    boolean active = true;
}

public class Ring {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.println("Enter number of processes:");
        int n = sc.nextInt();

        Process p[] = new Process[n];

        for (int i = 0; i < n; i++) {
            p[i] = new Process();
            System.out.println("Enter ID for process " + (i + 1) + ":");
            p[i].id = sc.nextInt();
        }

        // Assume highest ID is coordinator
        int coordinator = p[0].id;
        for (int i = 1; i < n; i++) {
            if (p[i].id > coordinator)
                coordinator = p[i].id;
        }

        System.out.println("Initial Coordinator: " + coordinator);

        while (true) {
            System.out.println("\n1. Start Election");
            System.out.println("2. Exit");
            int ch = sc.nextInt();

            switch (ch) {
                case 1:
                    System.out.println("Enter initiator index (0 to " + (n - 1) + "):");
                    int init = sc.nextInt();

                    int current = init;
                    int maxId = p[init].id;

                    System.out.println("Election message passing:");

                    do {
                        int next = (current + 1) % n;

                        if (p[next].active) {
                            System.out.println("Process " + p[current].id +
                                    " sends message to " + p[next].id);

                            if (p[next].id > maxId)
                                maxId = p[next].id;
                        }

                        current = next;

                    } while (current != init);

                    coordinator = maxId;
                    System.out.println("New Coordinator is: " + coordinator);
                    break;

                case 2:
                    System.out.println("Program terminated");
                    return;

                default:
                    System.out.println("Invalid choice");
            }
        }
    }
}
