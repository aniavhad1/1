import java.io.*;

class BullyAlgo {
    int cood, ch;
    int prc[];

    public void election(int n) throws IOException {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        System.out.println("\nCoordinator has crashed!");

        System.out.println("Enter initiator process:");
        int init = Integer.parseInt(br.readLine());

        if (init < 1 || init > n || prc[init - 1] == 0) {
            System.out.println("Invalid initiator");
            return;
        }

        // Send election messages
        for (int i = init; i < n; i++) {
            if (prc[i] == 1) {
                System.out.println("Process " + init + " sends message to Process " + (i + 1));
            }
        }

        // Find highest alive process
        for (int i = n - 1; i >= 0; i--) {
            if (prc[i] == 1) {
                cood = i + 1;
                System.out.println("\nNew Coordinator is Process " + cood);
                break;
            }
        }
    }

    public void bully() throws IOException {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

        System.out.println("Enter number of processes:");
        int n = Integer.parseInt(br.readLine());

        prc = new int[n];

        for (int i = 0; i < n; i++)
            prc[i] = 1;

        cood = n;

        do {
            System.out.println("\n1. Crash Process");
            System.out.println("2. Recover Process");
            System.out.println("3. Display Coordinator");
            System.out.println("4. Exit");

            ch = Integer.parseInt(br.readLine());

            switch (ch) {
                case 1:
                    System.out.println("Enter process to crash:");
                    int cp = Integer.parseInt(br.readLine());

                    if (cp < 1 || cp > n) {
                        System.out.println("Invalid process");
                    } else if (prc[cp - 1] == 1) {
                        prc[cp - 1] = 0;
                        System.out.println("Process " + cp + " crashed");

                        if (cp == cood)
                            election(n);
                    } else {
                        System.out.println("Already crashed");
                    }
                    break;

                case 2:
                    System.out.println("Enter process to recover:");
                    int rp = Integer.parseInt(br.readLine());

                    if (rp < 1 || rp > n) {
                        System.out.println("Invalid process");
                    } else if (prc[rp - 1] == 0) {
                        prc[rp - 1] = 1;
                        System.out.println("Process " + rp + " recovered");

                        if (rp > cood) {
                            cood = rp;
                            System.out.println("New Coordinator is " + cood);
                        }
                    } else {
                        System.out.println("Already active");
                    }
                    break;

                case 3:
                    System.out.println("Current Coordinator: " + cood);
                    break;

                case 4:
                    System.exit(0);
            }
        } while (ch != 4);
    }

    public static void main(String args[]) throws IOException {
        BullyAlgo ob = new BullyAlgo();
        ob.bully();
    }
}
