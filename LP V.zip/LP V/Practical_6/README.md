## Compilation
javac BullyAlgo.java
javac Ring.java

## Run
java BullyAlgo
java Ring
